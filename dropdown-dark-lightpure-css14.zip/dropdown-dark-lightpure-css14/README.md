# Dropdown dark/light - pure css - #14

A Pen created on CodePen.io. Original URL: [https://codepen.io/ig_design/pen/MWKVrNR](https://codepen.io/ig_design/pen/MWKVrNR).

